# Another-UI Main pack
Minecraft Bedrock Resource pack

- main pack buatan saya sendiri, dan dibantu oleh beberapa teman-teman saya

Syarat Penggunaan:

 Dengan mengunduh, menggunakan, atau berinteraksi dengan cara apa pun dengan add-on ini, Anda menyetujui ketentuan berikut:

 - Tidak Ada Turunan.  Anda dapat me-remix, mengadaptasi, atau mengembangkan add-on tersebut asalkan untuk penggunaan pribadi (ini berarti Anda tidak boleh mempublikasikan atau mendistribusikannya di mana pun).
 - Non-Komersial.  Anda tidak boleh memonetisasi, menjual, atau mengambil keuntungan dari add-on ini dengan cara apa pun.
 - Redistribusi.  Anda tidak boleh mendistribusikan ulang atau memublikasikan ulang add-on tersebut.
 - Membagikan.  Anda tidak boleh membagikan tautan unduhan langsung atau tautan apa pun yang dibuat pengguna dari add-on tersebut.  Gunakan tautan repo resmi Github.
 - Atribusi.  Anda dapat memberikan kredit yang sesuai jika ada konten tambahan (UI, file, dll.) yang muncul di konten Anda, misalnya video.
 - Tidak ada bundling.  Anda tidak boleh menyertakan file add-on atau cuplikannya di add-on lain.  Namun, Anda dapat memberikan tautan ke halaman repo Github resmi pengaya tersebut.

# Feature

Resource pack pertama di bedrock yang memiliki chunk map, ore info dan lainnya Tanpa Menggunakan molang atau player entity.

saya membuat ini sendiri, dan melihat resource pack milik orang lain sebagai referensi ide untuk fitur jadi jika ada fitur2 basic yang mungkin mirip dengan resource pack lain, 
maka kemungkinan itu referensi atau kebetulan sama

# English
- The main pack is my own creation, assisted by some of my friends.

Terms of use:

By downloading, using or interacting in any way with this add-on, you agree to the following terms:

- No Derivates. You can remix, adapt or build upon the add-on as long as it is for private use (this means that you may not publish or distribute it anywhere).
- Non-Commercial. You may not monetise, sell, or profit from the add-on in any way.
- Redistribution. You may not redistribute or republish the add-on.
- Sharing. You may not share the direct download link or any user-made link of the add-on. Use the official Github repo link.
- Attribution. You may give proper credit if any of the add-on contents (UI, files, etc.) appear in your content, such as videos.
- No bundling. You may not include the add-on files or snippets from them in other add-ons. You may, however, provide a link to the add-on’s official Github repo page.

# Features

The first bedrock resource pack with a chunk map, ore info, and more without using molang or player entity.

I created this myself, taking inspiration from other people's resource packs for feature ideas. So, if there are basic features that may resemble those in other resource packs, it is likely either a reference or a coincidence.
